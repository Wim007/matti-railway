ALTER TABLE `actions` MODIFY COLUMN `userId` varchar(255) NOT NULL;--> statement-breakpoint
ALTER TABLE `themes` MODIFY COLUMN `userId` varchar(255) NOT NULL;